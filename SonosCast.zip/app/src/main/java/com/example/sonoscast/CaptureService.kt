package com.example.sonoscast

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Capte tout le son joué par les autres applis, l'encode en AAC
 * et le diffuse sur le réseau pour que la Sonos le lise comme une radio.
 */
class CaptureService : Service() {

    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var server: LiveStreamServer? = null
    private var worker: Thread? = null
    private var wifiLock: WifiManager.WifiLock? = null
    @Volatile private var running = false
    private var mutedByUs = false
    private var cleaned = false
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                goForeground()
                val data = projectionData(intent)
                val ok = data != null && begin(
                    intent.getIntExtra(EXTRA_CODE, 0), data, intent.getBooleanExtra(EXTRA_MUTE, true)
                )
                if (!ok) stopSelf()
            }
            ACTION_MUTE -> if (running) setDeviceMuted(intent.getBooleanExtra(EXTRA_MUTE, true)) else stopSelf()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun projectionData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_DATA)

    private fun goForeground() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Diffusion vers la Sonos", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("SonosCast")
            .setContentText("Le son du téléphone part sur ta Sonos")
            .setContentIntent(openApp)
            .addAction(0, "Arrêter", stop)
            .setOngoing(true)
            .setSilent(true)
            .build()
        ServiceCompat.startForeground(this, 2, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    @SuppressLint("MissingPermission")
    private fun begin(code: Int, data: Intent, mute: Boolean): Boolean {
        if (running) return true
        return try {
            val manager = getSystemService(MediaProjectionManager::class.java)
            val mp = manager.getMediaProjection(code, data) ?: return false
            projection = mp
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopSelf() }
                }
            }, main)

            val config = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(maxOf(minBuffer * 4, 32 * 1024))
                .setAudioPlaybackCaptureConfig(config)
                .build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                return false
            }
            record = rec

            val srv = LiveStreamServer()
            srv.start()
            server = srv

            val encoder = AacEncoder(SAMPLE_RATE, 2, 192_000)

            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifiLock = wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "sonoscast-live").apply {
                setReferenceCounted(false)
                acquire()
            }

            if (mute) setDeviceMuted(true)

            running = true
            rec.startRecording()
            worker = thread(name = "sonoscast-capture") { captureLoop(rec, encoder, srv) }
            LiveState.running.value = true
            true
        } catch (e: Exception) {
            Log.e(TAG, "Capture impossible", e)
            cleanup()
            false
        }
    }

    private fun captureLoop(rec: AudioRecord, encoder: AacEncoder, srv: LiveStreamServer) {
        val buffer = ByteArray(4096) // ~23 ms de son
        var lastLevel = 0L
        try {
            while (running) {
                val n = rec.read(buffer, 0, buffer.size)
                if (n < 0) break
                if (n == 0) continue
                val now = SystemClock.elapsedRealtime()
                if (now - lastLevel > 40) {
                    LiveState.level.value = levelOf(buffer, n)
                    lastLevel = now
                }
                encoder.encode(buffer, n) { srv.broadcast(it) }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erreur de capture", e)
        } finally {
            encoder.release()
            if (running) main.post { stopSelf() }
        }
    }

    private fun levelOf(buffer: ByteArray, n: Int): Float {
        var sum = 0.0
        var count = 0
        var i = 0
        while (i + 1 < n) {
            val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort().toDouble()
            sum += sample * sample
            count++
            i += 2
        }
        if (count == 0) return 0f
        val rms = sqrt(sum / count) / 32768.0
        val db = 20 * log10(rms.coerceAtLeast(1e-5))
        return ((db + 40) / 40).toFloat().coerceIn(0f, 1f)
    }

    private fun setDeviceMuted(mute: Boolean) {
        val audio = getSystemService(AudioManager::class.java)
        if (mute && !mutedByUs) {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
            mutedByUs = true
        } else if (!mute && mutedByUs) {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            mutedByUs = false
        }
    }

    private fun cleanup() {
        if (cleaned) return
        cleaned = true
        running = false
        LiveState.running.value = false
        LiveState.level.value = 0f

        runCatching { record?.stop() }
        runCatching { worker?.join(1000) }
        runCatching { record?.release() }
        record = null
        worker = null

        server?.stop()
        server = null

        val p = projection
        projection = null
        runCatching { p?.stop() }

        if (mutedByUs) runCatching { setDeviceMuted(false) }
        wifiLock?.let { runCatching { it.release() } }
        wifiLock = null
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "SonosCast"
        private const val CHANNEL_ID = "sonoscast_live"
        private const val SAMPLE_RATE = 44100
        private const val ACTION_START = "com.example.sonoscast.START"
        private const val ACTION_STOP = "com.example.sonoscast.STOP"
        private const val ACTION_MUTE = "com.example.sonoscast.MUTE"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"
        private const val EXTRA_MUTE = "mute"

        fun start(context: Context, resultCode: Int, data: Intent, mute: Boolean) {
            val intent = Intent(context, CaptureService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
                .putExtra(EXTRA_MUTE, mute)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, CaptureService::class.java))
        }

        fun setMute(context: Context, mute: Boolean) {
            if (!LiveState.running.value) return
            context.startService(
                Intent(context, CaptureService::class.java).setAction(ACTION_MUTE).putExtra(EXTRA_MUTE, mute)
            )
        }
    }
}
