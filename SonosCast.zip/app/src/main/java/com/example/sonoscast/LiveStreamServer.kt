package com.example.sonoscast

import java.io.BufferedOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Petit serveur façon "radio internet" : chaque enceinte connectée reçoit
 * le flux AAC en continu, sans fin, comme une webradio classique.
 */
class LiveStreamServer(private val port: Int = PORT) {

    private class Client(val socket: Socket, val queue: ArrayBlockingQueue<ByteArray>)

    private val clients = CopyOnWriteArrayList<Client>()
    @Volatile private var serverSocket: ServerSocket? = null

    fun start() {
        if (serverSocket != null) return
        val ss = ServerSocket()
        ss.reuseAddress = true
        ss.bind(InetSocketAddress(port))
        serverSocket = ss
        thread(name = "sonoscast-live-accept", isDaemon = true) {
            while (!ss.isClosed) {
                val socket = try { ss.accept() } catch (e: IOException) { break }
                thread(name = "sonoscast-live-client", isDaemon = true) { handle(socket) }
            }
        }
    }

    private fun handle(socket: Socket) {
        var client: Client? = null
        try {
            socket.tcpNoDelay = true
            socket.soTimeout = 5000
            val reader = socket.getInputStream().bufferedReader(Charsets.ISO_8859_1)
            val requestLine = reader.readLine() ?: return
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isEmpty()) break
            }
            val out = BufferedOutputStream(socket.getOutputStream(), 16 * 1024)
            if (!requestLine.contains("/live")) {
                out.write("HTTP/1.0 404 Not Found\r\nContent-Length: 0\r\n\r\n".toByteArray())
                out.flush()
                return
            }
            out.write(
                ("HTTP/1.0 200 OK\r\n" +
                    "Content-Type: audio/aac\r\n" +
                    "Cache-Control: no-cache, no-store\r\n" +
                    "Pragma: no-cache\r\n" +
                    "icy-name: SonosCast\r\n" +
                    "icy-br: 192\r\n" +
                    "Connection: close\r\n\r\n").toByteArray()
            )
            out.flush()
            if (requestLine.startsWith("HEAD")) return

            val c = Client(socket, ArrayBlockingQueue(512))
            client = c
            clients += c
            socket.soTimeout = 0
            while (!socket.isClosed) {
                val chunk = c.queue.poll(2, TimeUnit.SECONDS) ?: continue
                if (chunk === END) break
                out.write(chunk)
                if (c.queue.isEmpty()) out.flush()
            }
        } catch (_: IOException) {
            // l'enceinte s'est déconnectée
        } catch (_: InterruptedException) {
        } finally {
            client?.let { clients -= it }
            runCatching { socket.close() }
        }
    }

    /** Envoie une trame audio à toutes les enceintes connectées. */
    fun broadcast(frame: ByteArray) {
        for (c in clients) {
            if (!c.queue.offer(frame)) {
                // Enceinte trop lente : on vide pour repartir sur du son récent
                c.queue.clear()
                c.queue.offer(frame)
            }
        }
    }

    fun stop() {
        runCatching { serverSocket?.close() }
        serverSocket = null
        for (c in clients) {
            c.queue.clear()
            c.queue.offer(END)
            runCatching { c.socket.close() }
        }
        clients.clear()
    }

    companion object {
        const val PORT = 8766
        private val END = ByteArray(0)
    }
}
