package com.example.sonoscast

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.session.MediaController
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.util.UUID

enum class Mode { PHONE, FILES }

enum class Transport { PREV, REW, PLAY, PAUSE, STOP, FWD, NEXT }

data class Song(
    val uri: Uri,
    val title: String,
    val mime: String,
    val size: Long,
    val ext: String,
)

data class HifiState(
    val groups: List<SonosGroup> = emptyList(),
    val selected: SonosGroup? = null,
    val searching: Boolean = false,
    val mode: Mode = Mode.PHONE,
    // Mode fichiers
    val queue: List<Song> = emptyList(),
    val index: Int = 0,
    val filePlaying: Boolean = false,
    val filePaused: Boolean = false,
    // Mode téléphone
    val streaming: Boolean = false,
    val connecting: Boolean = false,
    val muteDevice: Boolean = true,
    val mediaAccess: Boolean = false,
    val nowTitle: String? = null,
    val nowArtist: String? = null,
    val phonePlaying: Boolean = false,
    // Commun
    val volume: Int = 20,
    val eq: EqSettings = EqSettings(),
    val bass: Int = 0,
    val treble: Int = 0,
    val loudness: Boolean = true,
    val message: String? = null,
) {
    val currentSong: Song? get() = queue.getOrNull(index)
}

/**
 * Le cerveau de l'appli. Il vit aussi longtemps que l'appli elle-même,
 * donc rien n'est perdu quand on revient depuis la notification.
 */
object HifiController {

    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(HifiState())
    val state: StateFlow<HifiState> = _state.asStateFlow()

    private var initialized = false
    private var pollJob: Job? = null
    private var saveEqJob: Job? = null
    private val throttleJobs = mutableMapOf<String, Job>()
    private var streamJob: Job? = null
    private var messageJob: Job? = null
    private var silentTicks = 0

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        app = context.applicationContext
        prefs = app.getSharedPreferences("sonoscast", Context.MODE_PRIVATE)
        val eq = EqSettings.decode(prefs.getString("eq", null))
        EqStore.current = eq
        _state.update { it.copy(mediaAccess = PhoneMedia.hasAccess(app), eq = eq) }
        discover()

        // Titre en cours dans les autres applis + détection d'un flux muet
        scope.launch {
            while (isActive) {
                val s = _state.value
                if (s.mode == Mode.PHONE) {
                    val np = PhoneMedia.nowPlaying(app)
                    _state.update {
                        it.copy(
                            nowTitle = np?.title,
                            nowArtist = np?.artist,
                            phonePlaying = np?.playing == true,
                            mediaAccess = PhoneMedia.hasAccess(app),
                        )
                    }
                    if (s.streaming && np?.playing == true && LiveState.level.value < 0.03f) silentTicks++
                    else silentTicks = 0
                    if (silentTicks == 6) {
                        notify(
                            if (s.muteDevice) "Aucun son capté : désactive « Couper le haut-parleur du téléphone »"
                            else "Aucun son capté : cette appli bloque peut-être la capture"
                        )
                    }
                }
                delay(1000)
            }
        }

        // Si Android coupe la capture (bouton « Arrêter » de la notification), on arrête la Sonos
        scope.launch {
            LiveState.running.collect { running ->
                if (!running && _state.value.streaming) {
                    _state.update { it.copy(streaming = false) }
                    _state.value.selected?.let { g -> runCatching { SonosController.stop(g.ip) } }
                }
            }
        }
    }

    fun refreshAccess() {
        if (!initialized) return
        _state.update { it.copy(mediaAccess = PhoneMedia.hasAccess(app)) }
    }

    fun notify(message: String) {
        _state.update { it.copy(message = message) }
        messageJob?.cancel()
        messageJob = scope.launch {
            delay(7000)
            _state.update { s -> if (s.message == message) s.copy(message = null) else s }
        }
    }

    // ---------- Enceintes ----------

    fun discover() {
        scope.launch {
            _state.update { it.copy(searching = true) }
            val groups = runCatching { SonosDiscovery.discover(app) }.getOrDefault(emptyList())
            _state.update { s ->
                s.copy(
                    searching = false,
                    groups = groups,
                    selected = groups.firstOrNull { it.ip == s.selected?.ip } ?: groups.firstOrNull(),
                )
            }
            if (groups.isEmpty()) notify("Aucune enceinte trouvée : vérifie que tu es sur le même Wi-Fi")
            refreshVolume()
        }
    }

    fun select(group: SonosGroup) {
        act {
            val s = _state.value
            if (s.selected?.ip == group.ip) return@act
            val old = s.selected
            _state.update { it.copy(selected = group) }
            refreshVolume()
            if (s.streaming) {
                old?.let { runCatching { SonosController.stop(it.ip) } }
                connectStream(group)
            } else if (s.filePlaying || s.filePaused) {
                pollJob?.cancel()
                old?.let { runCatching { SonosController.stop(it.ip) } }
                playIndex(s.index)
            }
        }
    }

    // ---------- Modes ----------

    fun setMode(mode: Mode) {
        act {
            val s = _state.value
            if (s.mode == mode) return@act
            if (s.streaming || s.connecting) {
                streamJob?.cancel()
                stopStreamingInternal()
            }
            if (s.filePlaying || s.filePaused) stopFilesInternal()
            _state.update { it.copy(mode = mode, message = null) }
        }
    }

    // ---------- Volume ----------

    fun setVolume(volume: Int) {
        _state.update { it.copy(volume = volume.coerceIn(0, 100)) }
        throttle("volume", { _state.value.volume }) { g, v -> SonosController.setVolume(g.ip, v) }
    }

    /** Envoie la dernière valeur au plus toutes les 120 ms pendant qu'on tourne un bouton. */
    private fun throttle(key: String, read: () -> Int, send: suspend (SonosGroup, Int) -> Unit) {
        if (throttleJobs[key]?.isActive == true) return
        throttleJobs[key] = scope.launch {
            var sent = Int.MIN_VALUE
            while (true) {
                delay(120)
                val v = read()
                if (v == sent) break
                val g = _state.value.selected ?: break
                runCatching { send(g, v) }
                sent = v
            }
        }
    }

    private suspend fun refreshVolume() {
        val g = _state.value.selected ?: return
        runCatching { SonosController.getVolume(g.ip) }
            .onSuccess { v -> _state.update { it.copy(volume = v) } }
        runCatching { SonosController.getTone(g.ip) }
            .onSuccess { t -> _state.update { it.copy(bass = t.bass, treble = t.treble, loudness = t.loudness) } }
    }

    // ---------- Égaliseur (son du téléphone) ----------

    fun toggleEq() = updateEq { it.copy(enabled = !it.enabled) }

    fun setEqGain(band: Int, db: Float) = updateEq { eq ->
        val gains = eq.gains.toMutableList()
        gains[band] = db.coerceIn(-EQ_MAX_DB, EQ_MAX_DB)
        eq.copy(gains = gains, preset = null)
    }

    fun setPreamp(db: Float) = updateEq { it.copy(preamp = db.coerceIn(-EQ_MAX_DB, EQ_MAX_DB)) }

    fun applyPreset(name: String) {
        val preset = EqPresets.find(name) ?: return
        updateEq { it.copy(gains = preset.gains, preamp = preset.preamp, preset = preset.name, enabled = true) }
    }

    private fun updateEq(change: (EqSettings) -> EqSettings) {
        val eq = change(_state.value.eq)
        EqStore.current = eq
        _state.update { it.copy(eq = eq) }
        saveEqJob?.cancel()
        saveEqJob = scope.launch {
            delay(500)
            prefs.edit().putString("eq", eq.encode()).apply()
        }
    }

    // ---------- Tonalité de l'enceinte ----------

    fun setBass(value: Int) {
        _state.update { it.copy(bass = value.coerceIn(-10, 10)) }
        throttle("bass", { _state.value.bass }) { g, v -> SonosController.setBass(g, v) }
    }

    fun setTreble(value: Int) {
        _state.update { it.copy(treble = value.coerceIn(-10, 10)) }
        throttle("treble", { _state.value.treble }) { g, v -> SonosController.setTreble(g, v) }
    }

    fun toggleLoudness() {
        val on = !_state.value.loudness
        _state.update { it.copy(loudness = on) }
        act {
            val g = _state.value.selected ?: return@act
            SonosController.setLoudness(g, on)
        }
    }

    // ---------- Touches de la chaîne ----------

    fun transport(t: Transport) {
        when (t) {
            Transport.PREV -> previous()
            Transport.REW -> seek(-15)
            Transport.PLAY -> play()
            Transport.PAUSE -> pause()
            Transport.STOP -> stop()
            Transport.FWD -> seek(15)
            Transport.NEXT -> next()
        }
    }

    private fun play() = act {
        val s = _state.value
        if (s.mode == Mode.PHONE) {
            phone { it.transportControls.play() }
            return@act
        }
        val g = s.selected ?: error("Choisis d’abord une enceinte")
        when {
            s.filePaused -> {
                SonosController.play(g.ip)
                _state.update { it.copy(filePlaying = true, filePaused = false) }
                startPolling()
            }
            s.filePlaying -> Unit
            s.queue.isEmpty() -> error("Choisis d’abord des morceaux")
            else -> playIndex(s.index)
        }
    }

    private fun pause() = act {
        val s = _state.value
        if (s.mode == Mode.PHONE) {
            phone { it.transportControls.pause() }
            return@act
        }
        if (!s.filePlaying) return@act
        val g = s.selected ?: return@act
        pollJob?.cancel()
        SonosController.pause(g.ip)
        _state.update { it.copy(filePlaying = false, filePaused = true) }
    }

    private fun stop() = act {
        if (_state.value.mode == Mode.PHONE) {
            phone { it.transportControls.stop() }
        } else {
            stopFilesInternal()
        }
    }

    private fun previous() = act {
        val s = _state.value
        if (s.mode == Mode.PHONE) {
            phone { it.transportControls.skipToPrevious() }
            return@act
        }
        val g = s.selected ?: error("Choisis d’abord une enceinte")
        if (s.queue.isEmpty()) return@act
        if (s.index > 0) playIndex(s.index - 1)
        else if (s.filePlaying || s.filePaused) SonosController.seekTo(g.ip, 0)
    }

    private fun next() = act {
        val s = _state.value
        if (s.mode == Mode.PHONE) {
            phone { it.transportControls.skipToNext() }
            return@act
        }
        if (s.index < s.queue.lastIndex) playIndex(s.index + 1)
    }

    private fun seek(deltaSeconds: Int) = act {
        val s = _state.value
        if (s.mode == Mode.PHONE) {
            if (!PhoneMedia.hasAccess(app)) {
                notify("Autorise l’accès aux contrôles média pour piloter tes applis")
            } else if (!PhoneMedia.seekBy(app, deltaSeconds * 1000L)) {
                notify("Cette appli ne permet pas d’avancer ou de reculer")
            }
            return@act
        }
        if (!s.filePlaying && !s.filePaused) return@act
        val g = s.selected ?: return@act
        SonosController.seekBy(g.ip, deltaSeconds)
    }

    private fun phone(action: (MediaController) -> Unit) {
        if (!PhoneMedia.command(app, action)) {
            notify(
                if (!PhoneMedia.hasAccess(app)) "Autorise l’accès aux contrôles média pour piloter tes applis"
                else "Lance d’abord la musique dans une appli"
            )
        }
    }

    // ---------- Mode fichiers ----------

    fun setQueue(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val songs = uris.map { songFrom(it) }
        _state.update { it.copy(queue = songs, index = 0, filePaused = false) }
        act {
            if (_state.value.selected == null) error("Choisis d’abord une enceinte")
            pollJob?.cancel()
            playIndex(0)
        }
    }

    private fun songFrom(uri: Uri): Song {
        val resolver = app.contentResolver
        runCatching { resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        var name = "Morceau"
        var size = -1L
        runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        c.getString(0)?.let { name = it }
                        if (!c.isNull(1)) size = c.getLong(1)
                    }
                }
        }
        val mime = resolver.getType(uri) ?: "audio/mpeg"
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
            ?: name.substringAfterLast('.', "mp3")
        return Song(uri, name.substringBeforeLast('.'), mime, size, ext)
    }

    private suspend fun playIndex(i: Int) {
        val s = _state.value
        val g = s.selected ?: error("Choisis d’abord une enceinte")
        val song = s.queue.getOrNull(i) ?: error("Choisis d’abord des morceaux")
        val phoneIp = localIpAddress() ?: error("Le téléphone n’est pas connecté au Wi-Fi")
        val token = UUID.randomUUID().toString().take(8)
        withContext(Dispatchers.IO) {
            ServerHolder.ensureStarted(app).setTrack(
                AudioServer.Track(song.uri, song.mime, song.size, song.title, token, song.ext)
            )
        }
        PlaybackService.start(app)
        SonosController.playUri(g.ip, "http://$phoneIp:${AudioServer.PORT}/$token.${song.ext}", song.title, song.mime)
        _state.update { it.copy(index = i, filePlaying = true, filePaused = false, message = null) }
        startPolling()
    }

    private suspend fun stopFilesInternal() {
        pollJob?.cancel()
        _state.value.selected?.let { runCatching { SonosController.stop(it.ip) } }
        PlaybackService.stop(app)
        _state.update { it.copy(filePlaying = false, filePaused = false) }
    }

    /** Surveille la Sonos pour enchaîner automatiquement le morceau suivant. */
    private fun startPolling() {
        pollJob?.cancel()
        pollJob = scope.launch {
            var seenPlaying = false
            while (isActive) {
                delay(2000)
                val s = _state.value
                if (!s.filePlaying) return@launch
                val g = s.selected ?: continue
                val st = runCatching { SonosController.transportState(g.ip) }.getOrNull() ?: continue
                when (st) {
                    "PLAYING" -> {
                        seenPlaying = true
                    }
                    "PAUSED_PLAYBACK" -> if (seenPlaying) {
                        _state.update { it.copy(filePlaying = false, filePaused = true) }
                        return@launch
                    }
                    "STOPPED" -> if (seenPlaying) {
                        if (s.index < s.queue.lastIndex) {
                            act { playIndex(s.index + 1) }
                        } else {
                            PlaybackService.stop(app)
                            _state.update { it.copy(filePlaying = false, filePaused = false, index = 0) }
                        }
                        return@launch
                    }
                }
            }
        }
    }

    // ---------- Mode téléphone ----------

    fun toggleMute() {
        val mute = !_state.value.muteDevice
        _state.update { it.copy(muteDevice = mute) }
        CaptureService.setMute(app, mute)
    }

    /** Appelé une fois que l'utilisateur a accepté la capture du son. */
    fun startStreaming(resultCode: Int, data: Intent) {
        streamJob?.cancel()
        streamJob = act {
            val group = _state.value.selected ?: error("Choisis d’abord une enceinte")
            _state.update { it.copy(connecting = true, message = null) }
            try {
                CaptureService.start(app, resultCode, data, _state.value.muteDevice)
                withTimeoutOrNull(6000) { LiveState.running.first { it } }
                    ?: error("Impossible de capter le son du téléphone")
                connectStream(group)
            } catch (e: Exception) {
                CaptureService.stop(app)
                throw e
            } finally {
                _state.update { it.copy(connecting = false) }
            }
        }
    }

    fun stopStreaming() {
        streamJob?.cancel()
        act { stopStreamingInternal() }
    }

    private suspend fun connectStream(group: SonosGroup) {
        val phoneIp = localIpAddress() ?: error("Le téléphone n’est pas connecté au Wi-Fi")
        SonosController.playLiveStream(group.ip, phoneIp, LiveStreamServer.PORT)
        _state.update { it.copy(streaming = true, message = null) }
    }

    private suspend fun stopStreamingInternal() {
        _state.update { it.copy(streaming = false, connecting = false) }
        _state.value.selected?.let { runCatching { SonosController.stop(it.ip) } }
        CaptureService.stop(app)
    }

    // ---------- Outils ----------

    private fun act(block: suspend CoroutineScope.() -> Unit): Job = scope.launch {
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: SocketTimeoutException) {
            notify("L’enceinte ne répond pas")
        } catch (e: ConnectException) {
            notify("Impossible de joindre l’enceinte")
        } catch (e: Exception) {
            notify(e.message ?: "Erreur inattendue")
        }
    }
}
