package com.example.sonoscast

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val dark = isSystemInDarkTheme()
            val colors = when {
                Build.VERSION.SDK_INT >= 31 ->
                    if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = colors) {
                Surface(Modifier.fillMaxSize()) { SonosScreen(vm) }
            }
        }
    }
}

@Composable
fun SonosScreen(vm: MainViewModel) {
    val s by vm.state.collectAsState()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(vm::onFilePicked)
    }

    // Android 13+ : autoriser la notification du service de lecture
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("SonosCast", style = MaterialTheme.typography.headlineMedium)

        // Enceintes
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Enceintes", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = vm::discover, enabled = !s.searching) {
                Text(if (s.searching) "Recherche…" else "Rechercher")
            }
        }
        if (s.searching) LinearProgressIndicator(Modifier.fillMaxWidth())

        Column {
            s.groups.forEach { group ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.select(group) }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = group == s.selected, onClick = { vm.select(group) })
                    Text(group.name, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }

        HorizontalDivider()

        // Morceau
        Text("Morceau", style = MaterialTheme.typography.titleMedium)
        OutlinedButton(
            onClick = { picker.launch(arrayOf("audio/*")) },
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(
                s.trackTitle ?: "Choisir un fichier audio",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        val canPlay = s.selected != null && s.trackTitle != null
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = vm::togglePlay, enabled = canPlay, modifier = Modifier.weight(1f)) {
                Text(if (s.playing) "Pause" else "Lire")
            }
            OutlinedButton(onClick = vm::stop, enabled = canPlay, modifier = Modifier.weight(1f)) {
                Text("Arrêter")
            }
        }

        // Volume
        Text("Volume : ${s.volume}", style = MaterialTheme.typography.titleMedium)
        Slider(
            value = s.volume.toFloat(),
            onValueChange = { vm.onVolumeChange(it.roundToInt()) },
            onValueChangeFinished = vm::commitVolume,
            valueRange = 0f..100f,
            enabled = s.selected != null,
        )

        s.message?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
