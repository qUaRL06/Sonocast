package com.example.sonoscast

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        HifiController.init(this)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        setContent { HifiApp() }
    }

    override fun onResume() {
        super.onResume()
        HifiController.refreshAccess()
    }
}

@Composable
fun HifiApp() {
    val context = LocalContext.current
    val state by HifiController.state.collectAsState()
    val level by LiveState.level.collectAsState()

    // 1) Autorisation Android de capter le son des autres applis
    val projectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            HifiController.startStreaming(result.resultCode, data)
        } else {
            HifiController.notify("Diffusion annulée")
        }
    }

    fun askProjection() {
        val manager = context.getSystemService(MediaProjectionManager::class.java)
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            // Propose directement « tout l'écran » : c'est ce qui permet de capter le son
            manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            manager.createScreenCaptureIntent()
        }
        projectionLauncher.launch(intent)
    }

    // 2) Autorisation micro (obligatoire pour capter le son interne, rien n'est enregistré)
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) askProjection()
        else HifiController.notify("Autorise l’enregistrement audio pour capter le son du téléphone")
    }

    val filesLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        HifiController.setQueue(uris)
    }

    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !granted(context, Manifest.permission.POST_NOTIFICATIONS)) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    HifiScreen(
        state = state,
        level = level,
        onMode = HifiController::setMode,
        onSelect = HifiController::select,
        onSearch = HifiController::discover,
        onPickFiles = { filesLauncher.launch(arrayOf("audio/*")) },
        onStreamToggle = {
            when {
                state.streaming || state.connecting -> HifiController.stopStreaming()
                state.selected == null -> HifiController.notify("Choisis d’abord une enceinte")
                granted(context, Manifest.permission.RECORD_AUDIO) -> askProjection()
                else -> micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        },
        onMuteToggle = HifiController::toggleMute,
        onOpenAccess = { PhoneMedia.openAccessSettings(context) },
        onVolume = HifiController::setVolume,
        onTransport = HifiController::transport,
        onEqToggle = HifiController::toggleEq,
        onEqGain = HifiController::setEqGain,
        onPreamp = HifiController::setPreamp,
        onPreset = HifiController::applyPreset,
        onBass = HifiController::setBass,
        onTreble = HifiController::setTreble,
        onLoudness = HifiController::toggleLoudness,
    )
}

private fun granted(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
