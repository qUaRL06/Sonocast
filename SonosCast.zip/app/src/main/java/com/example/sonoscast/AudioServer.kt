package com.example.sonoscast

import android.content.Context
import android.net.Uri
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import java.io.InputStream
import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * La Sonos ne reçoit pas un flux "poussé" : elle télécharge une URL.
 * Ce serveur expose le morceau choisi sur http://<ip-du-téléphone>:8765/<token>.<ext>
 * et gère les requêtes Range (la Sonos s'en sert pour avancer dans le fichier).
 */
class AudioServer(private val context: Context) : NanoHTTPD(PORT) {

    data class Track(
        val uri: Uri,
        val mime: String,
        val size: Long,
        val title: String,
        val token: String,
        val ext: String,
    )

    @Volatile private var current: Track? = null

    fun setTrack(track: Track) { current = track }

    override fun serve(session: IHTTPSession): Response {
        val track = current
        if (track == null || !session.uri.startsWith("/${track.token}")) {
            return NanoHTTPD.newFixedLengthResponse(Status.NOT_FOUND, NanoHTTPD.MIME_PLAINTEXT, "Not found")
        }

        val input = try {
            context.contentResolver.openInputStream(track.uri)
        } catch (e: Exception) {
            null
        } ?: return NanoHTTPD.newFixedLengthResponse(
            Status.INTERNAL_ERROR, NanoHTTPD.MIME_PLAINTEXT, "Fichier illisible"
        )

        val size = track.size
        if (size <= 0) return NanoHTTPD.newChunkedResponse(Status.OK, track.mime, input)

        val range = session.headers["range"]?.let { parseRange(it, size) }
        return if (range == null) {
            NanoHTTPD.newFixedLengthResponse(Status.OK, track.mime, input, size).apply {
                addHeader("Accept-Ranges", "bytes")
            }
        } else {
            val (start, end) = range
            input.skipFully(start)
            NanoHTTPD.newFixedLengthResponse(Status.PARTIAL_CONTENT, track.mime, input, end - start + 1).apply {
                addHeader("Accept-Ranges", "bytes")
                addHeader("Content-Range", "bytes $start-$end/$size")
            }
        }
    }

    private fun parseRange(header: String, size: Long): Pair<Long, Long>? {
        val match = Regex("bytes=(\\d*)-(\\d*)").find(header) ?: return null
        val (a, b) = match.destructured
        val (start, end) = when {
            a.isEmpty() && b.isEmpty() -> return null
            a.isEmpty() -> (size - b.toLong()).coerceAtLeast(0) to size - 1
            else -> a.toLong() to (b.toLongOrNull()?.coerceAtMost(size - 1) ?: (size - 1))
        }
        return if (start > end || start >= size) null else start to end
    }

    private fun InputStream.skipFully(n: Long) {
        var remaining = n
        while (remaining > 0) {
            val skipped = skip(remaining)
            if (skipped > 0) remaining -= skipped
            else if (read() == -1) break
            else remaining--
        }
    }

    companion object {
        const val PORT = 8765
    }
}

/** Une seule instance du serveur pour toute l'app. */
object ServerHolder {
    private var server: AudioServer? = null

    @Synchronized
    fun ensureStarted(context: Context): AudioServer {
        val s = server ?: AudioServer(context.applicationContext).also { server = it }
        if (!s.isAlive) s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
        return s
    }

    @Synchronized
    fun stop() {
        server?.stop()
        server = null
    }
}

/** Adresse IPv4 du téléphone sur le Wi-Fi (celle que la Sonos va appeler). */
fun localIpAddress(): String? =
    NetworkInterface.getNetworkInterfaces().toList()
        .filter { it.isUp && !it.isLoopback }
        .sortedByDescending { it.name.startsWith("wlan") }
        .flatMap { it.inetAddresses.toList() }
        .filterIsInstance<Inet4Address>()
        .firstOrNull { it.isSiteLocalAddress }
        ?.hostAddress
