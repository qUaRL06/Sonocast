package com.example.sonoscast

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.inset
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/** Palette : façade alu sombre, joues en noyer, rétroéclairage ambré. */
private object Hifi {
    val chassis = Color(0xFF14110E)
    val plateTop = Color(0xFF35332F)
    val plateBottom = Color(0xFF1E1D1B)
    val engraving = Color(0xFFC9C2B4)
    val engravingDim = Color(0xFF857E72)
    val amber = Color(0xFFFFB547)
    val red = Color(0xFFC0392B)
    val ledRed = Color(0xFFFF4A3D)
    val ledOff = Color(0xFF3A2C1E)
    val vfdBack = Color(0xFF0A0C0B)
    val meterLight = Color(0xFFF7E6B8)
    val meterEdge = Color(0xFFD8A257)
    val ink = Color(0xFF2E2216)
    val woodLight = Color(0xFF6E4126)
    val woodDark = Color(0xFF3B2215)
    val keyTop = Color(0xFFE6E5E1)
    val keyBottom = Color(0xFFA6A5A0)
    val keySide = Color(0xFF5E5D59)
    val keyInk = Color(0xFF2A2927)
    val well = Color(0xFF0B0A09)
    val green = Color(0xFF39F26B)
}

@Composable
fun HifiScreen(
    state: HifiState,
    level: Float,
    onMode: (Mode) -> Unit,
    onSelect: (SonosGroup) -> Unit,
    onSearch: () -> Unit,
    onPickFiles: () -> Unit,
    onStreamToggle: () -> Unit,
    onMuteToggle: () -> Unit,
    onOpenAccess: () -> Unit,
    onVolume: (Int) -> Unit,
    onTransport: (Transport) -> Unit,
    onEqToggle: () -> Unit,
    onEqGain: (Int, Float) -> Unit,
    onPreamp: (Float) -> Unit,
    onPreset: (String) -> Unit,
    onBass: (Int) -> Unit,
    onTreble: (Int) -> Unit,
    onLoudness: () -> Unit,
) {
    // Texte de l'afficheur
    val speaker = state.selected?.name ?: "aucune enceinte"
    val line1: String
    val line2: String
    val line3: String
    if (state.mode == Mode.PHONE) {
        line1 = "Téléphone → $speaker"
        line2 = state.nowTitle ?: if (state.streaming) "En diffusion" else "Prêt à diffuser"
        line3 = state.message ?: state.nowArtist
            ?: if (state.streaming) "Son du téléphone en direct" else "Appuie sur le bouton de diffusion"
    } else {
        line1 = "Fichiers → $speaker"
        line2 = state.currentSong?.title ?: "Aucun morceau"
        val position = "Piste ${state.index + 1}/${state.queue.size}"
        line3 = state.message ?: when {
            state.queue.isEmpty() -> "Choisis des morceaux"
            state.filePlaying -> "$position en lecture"
            state.filePaused -> "$position en pause"
            else -> position
        }
    }

    // En mode fichiers, la Sonos joue seule : l'aiguille danse pour le plaisir des yeux
    var fakeLevel by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(state.mode, state.filePlaying) {
        if (state.mode == Mode.FILES && state.filePlaying) {
            while (true) {
                fakeLevel = 0.5f + Random.nextFloat() * 0.32f
                delay(170)
            }
        } else {
            fakeLevel = 0f
        }
    }
    val needleLevel = if (state.mode == Mode.PHONE) level else fakeLevel

    Box(
        Modifier
            .fillMaxSize()
            .background(Hifi.chassis)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .safeDrawingPadding()
                .padding(10.dp)
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .walnut()
                    .padding(10.dp)
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .brushedMetal()
                        .padding(horizontal = 16.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(22.dp),
                ) {
                    Header(active = state.streaming || state.filePlaying)

                    VfdDisplay(line1, line2, line3, alert = state.message != null)

                    VuMeter(
                        level = needleLevel,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    )

                    ModeSelector(state.mode, onMode)

                    TransportKeys(state, onTransport)

                    if (state.mode == Mode.PHONE) {
                        PhoneSource(state, onStreamToggle, onMuteToggle, onOpenAccess)
                    } else {
                        FileSource(state, onPickFiles)
                    }

                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Engraved("Volume")
                        VolumeKnob(
                            value = state.volume,
                            enabled = state.selected != null,
                            onChange = onVolume,
                        )
                        VfdText(state.volume.toString().padStart(2, '0'), 22.sp)
                    }

                    EqualizerPanel(state, onEqToggle, onEqGain, onPreamp, onPreset)

                    TonePanel(state, onBass, onTreble, onLoudness)

                    SpeakerPanel(state.groups, state.selected, state.searching, onSelect, onSearch)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Façade

@Composable
private fun Header(active: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(
                "SonosCast",
                color = Hifi.engraving,
                fontSize = 26.sp,
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Bold,
            )
            Engraved("Amplificateur de salon")
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Led(active, color = Hifi.ledRed, diameter = 10.dp)
            Spacer(Modifier.height(6.dp))
            Engraved("Signal")
        }
    }
}

@Composable
private fun Engraved(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier = modifier,
        color = Hifi.engravingDim,
        fontSize = 10.sp,
        letterSpacing = 2.sp,
        fontWeight = FontWeight.Medium,
    )
}

private fun Modifier.brushedMetal(): Modifier = drawBehind {
    drawRect(Brush.verticalGradient(listOf(Hifi.plateTop, Hifi.plateBottom)))
    var y = 0f
    var i = 0
    while (y < size.height) {
        val n = sin(i * 12.9898f) * 43758.547f
        val alpha = (n - floor(n)) * 0.05f
        drawLine(Color.White.copy(alpha = alpha), Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
        y += 2f
        i++
    }
    // Liseré lumineux en haut, ombre en bas : la plaque a de l'épaisseur
    drawLine(Color.White.copy(alpha = 0.18f), Offset(0f, 1f), Offset(size.width, 1f), strokeWidth = 2f)
    drawLine(Color.Black.copy(alpha = 0.5f), Offset(0f, size.height - 1f), Offset(size.width, size.height - 1f), strokeWidth = 2f)
}

private fun Modifier.walnut(): Modifier = drawBehind {
    drawRect(Brush.verticalGradient(listOf(Hifi.woodLight, Hifi.woodDark)))
    for (k in 0 until 22) {
        val x0 = size.width * (k + 0.5f) / 22f
        val path = Path().apply {
            moveTo(x0, 0f)
            var y = 0f
            while (y < size.height) {
                y += 30f
                lineTo(x0 + sin(y / 80f + k * 1.7f) * 7f, y)
            }
        }
        drawPath(path, Color.Black.copy(alpha = 0.16f), style = Stroke(width = 1.4f))
    }
}

@Composable
private fun Led(on: Boolean, color: Color = Hifi.amber, diameter: Dp = 8.dp) {
    Canvas(Modifier.size(diameter)) {
        val r = size.minDimension / 2
        if (on) drawCircle(color.copy(alpha = 0.3f), radius = r * 2.2f)
        drawCircle(if (on) color else Hifi.ledOff, radius = r)
        drawCircle(
            Color.White.copy(alpha = if (on) 0.55f else 0.12f),
            radius = r / 3,
            center = center + Offset(-r / 3, -r / 3),
        )
    }
}

// ---------------------------------------------------------------- Afficheur

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VfdDisplay(line1: String, line2: String, line3: String, alert: Boolean) {
    val shape = RoundedCornerShape(6.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Hifi.vfdBack)
            .border(1.dp, Color.Black, shape)
            .drawWithContent {
                drawContent()
                // reflet de la vitre
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.07f), Color.Transparent),
                        endY = size.height * 0.5f,
                    )
                )
            }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        VfdText(line1, 11.sp, Hifi.amber.copy(alpha = 0.6f))
        VfdText(line2, 19.sp, modifier = Modifier.basicMarquee())
        VfdText(line3, 12.sp, if (alert) Hifi.ledRed else Hifi.amber.copy(alpha = 0.8f))
    }
}

@Composable
private fun VfdText(
    text: String,
    size: TextUnit,
    color: Color = Hifi.amber,
    modifier: Modifier = Modifier,
) {
    Text(
        text,
        modifier = modifier,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        style = TextStyle(
            fontFamily = FontFamily.Monospace,
            fontSize = size,
            color = color,
            letterSpacing = 0.5.sp,
            shadow = Shadow(color = color.copy(alpha = 0.7f), offset = Offset.Zero, blurRadius = 12f),
        ),
    )
}

// ---------------------------------------------------------------- Vumètre

@Composable
private fun VuMeter(level: Float, modifier: Modifier = Modifier) {
    val needle by animateFloatAsState(
        targetValue = level,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 110f),
        label = "needle",
    )
    val measurer = rememberTextMeasurer()

    Canvas(modifier) {
        drawRoundRect(Hifi.well, cornerRadius = CornerRadius(10.dp.toPx()))
        inset(5.dp.toPx()) {
            val face = CornerRadius(7.dp.toPx())
            drawRoundRect(
                Brush.radialGradient(
                    listOf(Hifi.meterLight, Hifi.meterEdge),
                    center = Offset(size.width / 2, size.height * 0.8f),
                    radius = size.width * 0.7f,
                ),
                cornerRadius = face,
            )

            val pivot = Offset(size.width / 2, size.height * 1.08f)
            val radius = size.height * 0.80f
            val startDeg = -48f
            val sweepDeg = 96f

            fun pointAt(t: Float, r: Float): Offset {
                val a = Math.toRadians((startDeg + sweepDeg * t - 90f).toDouble())
                return Offset(pivot.x + r * cos(a).toFloat(), pivot.y + r * sin(a).toFloat())
            }

            val arcTopLeft = Offset(pivot.x - radius, pivot.y - radius)
            val arcSize = Size(radius * 2, radius * 2)
            drawArc(
                Hifi.ink, startAngle = -90f + startDeg, sweepAngle = sweepDeg * 0.75f, useCenter = false,
                topLeft = arcTopLeft, size = arcSize, style = Stroke(1.5.dp.toPx()),
            )
            drawArc(
                Hifi.red, startAngle = -90f + startDeg + sweepDeg * 0.75f, sweepAngle = sweepDeg * 0.25f,
                useCenter = false, topLeft = arcTopLeft, size = arcSize, style = Stroke(5.dp.toPx()),
            )

            for (i in 0..20) {
                val t = i / 20f
                drawLine(
                    if (t > 0.75f) Hifi.red else Hifi.ink,
                    pointAt(t, radius), pointAt(t, radius + 5.dp.toPx()),
                    strokeWidth = 1.dp.toPx(),
                )
            }
            val marks = listOf(0f to "-20", 0.3f to "-10", 0.5f to "-5", 0.63f to "-3", 0.75f to "0", 0.87f to "+1", 1f to "+3")
            for ((t, label) in marks) {
                val color = if (t >= 0.75f) Hifi.red else Hifi.ink
                drawLine(color, pointAt(t, radius), pointAt(t, radius + 10.dp.toPx()), strokeWidth = 1.6.dp.toPx())
                val layout = measurer.measure(label, TextStyle(fontSize = 10.sp, color = color, fontWeight = FontWeight.Medium))
                val p = pointAt(t, radius + 20.dp.toPx())
                drawText(layout, topLeft = Offset(p.x - layout.size.width / 2f, p.y - layout.size.height / 2f))
            }

            val vu = measurer.measure(
                "VU",
                TextStyle(fontSize = 18.sp, color = Hifi.ink, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold),
            )
            drawText(vu, topLeft = Offset(size.width / 2 - vu.size.width / 2f, size.height * 0.48f))

            // Aiguille et son ombre
            val tip = pointAt(needle.coerceIn(0f, 1.04f), radius + 8.dp.toPx())
            val shadowOffset = Offset(3.dp.toPx(), 3.dp.toPx())
            drawLine(
                Color.Black.copy(alpha = 0.2f), pivot + shadowOffset, tip + shadowOffset,
                strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round,
            )
            drawLine(Color(0xFF1A1410), pivot, tip, strokeWidth = 1.8.dp.toPx(), cap = StrokeCap.Round)

            // Cache du pivot
            drawRect(
                Brush.verticalGradient(listOf(Color(0xFF2A2622), Color(0xFF12100E)), startY = size.height * 0.86f),
                topLeft = Offset(0f, size.height * 0.86f),
                size = Size(size.width, size.height * 0.14f),
            )

            // Reflet de la vitre
            drawRoundRect(
                Brush.linearGradient(
                    listOf(Color.White.copy(alpha = 0.22f), Color.Transparent),
                    start = Offset.Zero,
                    end = Offset(size.width * 0.55f, size.height),
                ),
                cornerRadius = face,
            )
        }
    }
}

// ---------------------------------------------------------------- Sélecteur de source

@Composable
private fun ModeSelector(mode: Mode, onMode: (Mode) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Engraved("Source")
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Hifi.well)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            listOf(Mode.PHONE to "Téléphone", Mode.FILES to "Fichiers").forEach { (m, label) ->
                val on = m == mode
                Box(
                    Modifier
                        .weight(1f)
                        .height(46.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (on) Brush.verticalGradient(listOf(Color(0xFF5A5854), Color(0xFF2D2C29)))
                            else SolidColor(Color(0xFF171614))
                        )
                        .clickable { onMode(m) },
                    contentAlignment = Alignment.Center,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Led(on)
                        Spacer(Modifier.width(10.dp))
                        Text(label, color = if (on) Hifi.engraving else Hifi.engravingDim, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Touches

@Composable
private fun TransportKeys(state: HifiState, onTransport: (Transport) -> Unit) {
    val playing = if (state.mode == Mode.PHONE) state.phonePlaying else state.filePlaying
    val paused = if (state.mode == Mode.PHONE) !state.phonePlaying && state.nowTitle != null else state.filePaused
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Transport.entries.forEach { t ->
            HifiKey(
                icon = t,
                active = (t == Transport.PLAY && playing) || (t == Transport.PAUSE && paused),
                onClick = { onTransport(t) },
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun HifiKey(icon: Transport, active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val haptic = LocalHapticFeedback.current

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Led(active, diameter = 6.dp)
        Spacer(Modifier.height(8.dp))
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(58.dp)
                .clickable(interactionSource = interaction, indication = null) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                }
        ) {
            val pad = 2.dp.toPx()
            val travel = 4.dp.toPx()
            val press = if (pressed) travel * 0.8f else 0f
            val radius = CornerRadius(4.dp.toPx())

            drawRoundRect(Hifi.well, cornerRadius = CornerRadius(5.dp.toPx()))

            val faceTop = pad + press
            val faceHeight = size.height - pad * 2 - travel
            val width = size.width - pad * 2
            // tranche de la touche
            drawRoundRect(
                Hifi.keySide,
                topLeft = Offset(pad, faceTop),
                size = Size(width, faceHeight + travel - press),
                cornerRadius = radius,
            )
            // dessus de la touche
            drawRoundRect(
                Brush.verticalGradient(
                    if (pressed) listOf(Hifi.keyBottom, Hifi.keyTop) else listOf(Hifi.keyTop, Hifi.keyBottom),
                    startY = faceTop,
                    endY = faceTop + faceHeight,
                ),
                topLeft = Offset(pad, faceTop),
                size = Size(width, faceHeight),
                cornerRadius = radius,
            )
            drawLine(
                Color.White.copy(alpha = 0.7f),
                Offset(pad + 4f, faceTop + 1.5f),
                Offset(pad + width - 4f, faceTop + 1.5f),
                strokeWidth = 1.5f,
            )
            transportIcon(icon, Offset(size.width / 2, faceTop + faceHeight / 2), 8.dp.toPx(), Hifi.keyInk)
        }
    }
}

private fun DrawScope.transportIcon(t: Transport, c: Offset, s: Float, color: Color) {
    fun triangle(pointsLeft: Boolean, cx: Float) {
        val path = Path().apply {
            if (pointsLeft) {
                moveTo(cx + s * 0.5f, c.y - s * 0.6f)
                lineTo(cx + s * 0.5f, c.y + s * 0.6f)
                lineTo(cx - s * 0.5f, c.y)
            } else {
                moveTo(cx - s * 0.5f, c.y - s * 0.6f)
                lineTo(cx - s * 0.5f, c.y + s * 0.6f)
                lineTo(cx + s * 0.5f, c.y)
            }
            close()
        }
        drawPath(path, color)
    }

    fun bar(cx: Float, w: Float = s * 0.22f) {
        drawRect(color, topLeft = Offset(cx - w / 2, c.y - s * 0.6f), size = Size(w, s * 1.2f))
    }

    when (t) {
        Transport.PLAY -> triangle(false, c.x + s * 0.1f)
        Transport.PAUSE -> {
            bar(c.x - s * 0.3f, s * 0.3f)
            bar(c.x + s * 0.3f, s * 0.3f)
        }
        Transport.STOP -> drawRect(color, topLeft = Offset(c.x - s * 0.55f, c.y - s * 0.55f), size = Size(s * 1.1f, s * 1.1f))
        Transport.REW -> {
            triangle(true, c.x - s * 0.45f)
            triangle(true, c.x + s * 0.45f)
        }
        Transport.FWD -> {
            triangle(false, c.x - s * 0.45f)
            triangle(false, c.x + s * 0.45f)
        }
        Transport.PREV -> {
            bar(c.x - s * 0.62f)
            triangle(true, c.x + s * 0.15f)
        }
        Transport.NEXT -> {
            triangle(false, c.x - s * 0.15f)
            bar(c.x + s * 0.62f)
        }
    }
}

@Composable
private fun SmallKey(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box(
        modifier
            .clip(RoundedCornerShape(5.dp))
            .background(
                Brush.verticalGradient(
                    if (pressed) listOf(Hifi.keyBottom, Hifi.keyTop) else listOf(Hifi.keyTop, Hifi.keyBottom)
                )
            )
            .clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            color = Hifi.keyInk.copy(alpha = if (enabled) 1f else 0.4f),
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

// ---------------------------------------------------------------- Sources

@Composable
private fun PhoneSource(
    state: HifiState,
    onStreamToggle: () -> Unit,
    onMuteToggle: () -> Unit,
    onOpenAccess: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PowerButton(on = state.streaming, busy = state.connecting, onClick = onStreamToggle)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(
                    when {
                        state.connecting -> "Connexion à l’enceinte…"
                        state.streaming -> "En diffusion"
                        else -> "Diffuser le son du téléphone"
                    },
                    color = Hifi.engraving,
                    fontSize = 16.sp,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Tout ce que jouent tes applis part sur l’enceinte, avec 2 à 5 secondes de décalage.",
                    color = Hifi.engravingDim,
                    fontSize = 12.sp,
                )
            }
        }
        ToggleRow(on = state.muteDevice, label = "Couper le haut-parleur du téléphone", onClick = onMuteToggle)
        if (!state.mediaAccess) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Hifi.well)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    "Pour que les touches pilotent Spotify, YouTube ou Deezer, active SonosCast dans « Accès aux notifications ».",
                    color = Hifi.engravingDim,
                    fontSize = 12.sp,
                )
                SmallKey("Autoriser", onOpenAccess)
            }
        }
    }
}

@Composable
private fun PowerButton(on: Boolean, busy: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val haptic = LocalHapticFeedback.current
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "pulseAlpha",
    )
    Canvas(
        Modifier
            .size(92.dp)
            .clickable(interactionSource = interaction, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            }
    ) {
        val c = center
        val r = size.minDimension / 2
        val ring = when {
            busy -> pulse
            on -> 1f
            else -> 0.15f
        }
        drawCircle(Color.Black.copy(alpha = 0.5f), radius = r * 0.95f, center = c + Offset(0f, 3.dp.toPx()))
        drawCircle(Hifi.amber.copy(alpha = ring * 0.25f), radius = r, center = c)
        drawCircle(Hifi.amber.copy(alpha = ring), radius = r * 0.9f, center = c, style = Stroke(3.dp.toPx()))

        val br = r * 0.76f - if (pressed) 1.5.dp.toPx() else 0f
        drawCircle(
            Brush.radialGradient(
                listOf(Color(0xFF5E5C58), Color(0xFF22211F)),
                center = c + Offset(-br * 0.35f, -br * 0.35f),
                radius = br * 1.7f,
            ),
            radius = br,
            center = c,
        )
        drawCircle(Color.White.copy(alpha = 0.12f), radius = br, center = c, style = Stroke(1.dp.toPx()))

        val symbol = if (on || busy) Hifi.amber else Hifi.engravingDim
        val s = br * 0.42f
        drawArc(
            symbol, startAngle = -60f, sweepAngle = 300f, useCenter = false,
            topLeft = c - Offset(s, s), size = Size(s * 2, s * 2),
            style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
        )
        drawLine(symbol, c - Offset(0f, s * 1.15f), c - Offset(0f, s * 0.15f), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
    }
}

@Composable
private fun ToggleRow(on: Boolean, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Canvas(Modifier.size(width = 42.dp, height = 24.dp)) {
            val h = size.height
            drawRoundRect(Hifi.well, cornerRadius = CornerRadius(h / 2))
            if (on) drawRoundRect(Hifi.amber.copy(alpha = 0.3f), cornerRadius = CornerRadius(h / 2))
            val r = h / 2 - 3.dp.toPx()
            val cx = if (on) size.width - r - 3.dp.toPx() else r + 3.dp.toPx()
            drawCircle(
                Brush.radialGradient(
                    listOf(Hifi.keyTop, Color(0xFF7E7D79)),
                    center = Offset(cx - r * 0.3f, h / 2 - r * 0.3f),
                    radius = r * 1.6f,
                ),
                radius = r,
                center = Offset(cx, h / 2),
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(label, color = Hifi.engraving, fontSize = 14.sp)
    }
}

@Composable
private fun FileSource(state: HifiState, onPickFiles: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SmallKey(
            if (state.queue.isEmpty()) "Choisir des morceaux" else "Changer de morceaux",
            onPickFiles,
            Modifier.fillMaxWidth(),
        )
        if (state.queue.isNotEmpty()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Hifi.vfdBack)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                state.queue.take(30).forEachIndexed { i, song ->
                    val current = i == state.index
                    VfdText(
                        "${(i + 1).toString().padStart(2, '0')}  ${song.title}",
                        13.sp,
                        if (current) Hifi.amber else Hifi.amber.copy(alpha = 0.35f),
                    )
                }
                if (state.queue.size > 30) {
                    VfdText("+ ${state.queue.size - 30} autres", 12.sp, Hifi.amber.copy(alpha = 0.35f))
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Bouton de volume

@Composable
private fun VolumeKnob(value: Int, enabled: Boolean, onChange: (Int) -> Unit) {
    val current by rememberUpdatedState(value)
    var accumulated by remember { mutableFloatStateOf(0f) }
    val haptic = LocalHapticFeedback.current

    Canvas(
        Modifier
            .padding(vertical = 8.dp)
            .size(230.dp)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectDragGestures(onDragStart = { accumulated = current.toFloat() }) { change, drag ->
                    change.consume()
                    // Glisser vers le haut ou la droite pour monter le son
                    accumulated = (accumulated + (drag.x - drag.y) / 5f).coerceIn(0f, 100f)
                    val v = accumulated.roundToInt()
                    if (v != current) {
                        if (v % 5 == 0) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onChange(v)
                    }
                }
            }
    ) {
        val c = center
        val r = size.minDimension / 2
        val startDeg = -135f
        val sweepDeg = 270f
        fun polar(deg: Float, radius: Float): Offset {
            val a = Math.toRadians((deg - 90f).toDouble())
            return Offset(c.x + radius * cos(a).toFloat(), c.y + radius * sin(a).toFloat())
        }

        // Graduation, éclairée jusqu'au volume actuel
        for (i in 0..50) {
            val t = i / 50f
            val deg = startDeg + sweepDeg * t
            val major = i % 5 == 0
            val lit = enabled && t <= value / 100f
            drawLine(
                if (lit) Hifi.amber else Hifi.engravingDim.copy(alpha = 0.5f),
                polar(deg, r * 0.84f),
                polar(deg, if (major) r * 0.98f else r * 0.91f),
                strokeWidth = if (major) 2.dp.toPx() else 1.dp.toPx(),
                cap = StrokeCap.Round,
            )
        }

        val kr = r * 0.74f
        // Ombre portée
        drawCircle(Color.Black.copy(alpha = 0.55f), radius = kr * 1.02f, center = c + Offset(0f, 6.dp.toPx()))
        // Jupe moletée
        drawCircle(
            Brush.verticalGradient(listOf(Color(0xFF5C5A56), Color(0xFF1B1A18)), startY = c.y - kr, endY = c.y + kr),
            radius = kr,
            center = c,
        )
        for (i in 0 until 90) {
            val deg = i * 4f
            drawLine(Color.Black.copy(alpha = 0.4f), polar(deg, kr * 0.87f), polar(deg, kr), strokeWidth = 1.2f)
        }
        // Chapeau en alu brossé (reflet conique)
        val cr = kr * 0.82f
        drawCircle(
            Brush.sweepGradient(
                listOf(
                    Color(0xFF8F8D88), Color(0xFFE2E0DB), Color(0xFF85837E), Color(0xFFD3D1CC),
                    Color(0xFF8A8883), Color(0xFFE4E2DD), Color(0xFF8F8D88),
                ),
                center = c,
            ),
            radius = cr,
            center = c,
        )
        for (k in 1..14) {
            drawCircle(Color.Black.copy(alpha = 0.035f), radius = cr * k / 14f, center = c, style = Stroke(1f))
        }
        drawCircle(Color.White.copy(alpha = 0.3f), radius = cr, center = c, style = Stroke(1.dp.toPx()))

        // Repère lumineux
        val deg = startDeg + sweepDeg * (value / 100f)
        val color = if (enabled) Hifi.amber else Hifi.engravingDim
        if (enabled) {
            drawLine(color.copy(alpha = 0.35f), polar(deg, cr * 0.55f), polar(deg, cr * 0.9f), strokeWidth = 8.dp.toPx(), cap = StrokeCap.Round)
        }
        drawLine(color, polar(deg, cr * 0.55f), polar(deg, cr * 0.9f), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
    }
}

// ---------------------------------------------------------------- Enceintes

@Composable
private fun SpeakerPanel(
    groups: List<SonosGroup>,
    selected: SonosGroup?,
    searching: Boolean,
    onSelect: (SonosGroup) -> Unit,
    onSearch: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Engraved("Enceintes", Modifier.weight(1f))
            SmallKey(if (searching) "Recherche…" else "Chercher", onSearch, enabled = !searching)
        }
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(Hifi.well)
                .padding(vertical = 4.dp)
        ) {
            if (groups.isEmpty()) {
                Text(
                    if (searching) "Recherche des enceintes sur le Wi-Fi…" else "Aucune enceinte trouvée",
                    color = Hifi.engravingDim,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(14.dp),
                )
            }
            groups.forEach { g ->
                val on = g.ip == selected?.ip
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(g) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Led(on)
                    Spacer(Modifier.width(12.dp))
                    Text(g.name, color = if (on) Hifi.engraving else Hifi.engravingDim, fontSize = 15.sp)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Égaliseur

@Composable
private fun EqualizerPanel(
    state: HifiState,
    onToggle: () -> Unit,
    onGain: (Int, Float) -> Unit,
    onPreamp: (Float) -> Unit,
    onPreset: (String) -> Unit,
) {
    val eq = state.eq
    val phone = state.mode == Mode.PHONE
    val lit = phone && eq.enabled
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Engraved("Égaliseur", Modifier.weight(1f))
            Row(
                Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(Hifi.well)
                    .clickable(enabled = phone, onClick = onToggle)
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Led(lit, color = Hifi.green, diameter = 7.dp)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (eq.enabled) "Activé" else "Désactivé",
                    color = if (phone) Hifi.engraving else Hifi.engravingDim,
                    fontSize = 13.sp,
                )
            }
        }

        EqCurve(eq, lit)

        Row(
            Modifier
                .fillMaxWidth()
                .height(180.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            EqFader("Pré", eq.preamp, phone, lit, onPreamp, Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            EQ_LABELS.forEachIndexed { i, label ->
                EqFader(label, eq.gains[i], phone, lit, { onGain(i, it) }, Modifier.weight(1f))
            }
        }

        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            EqPresets.all.forEach { p ->
                PresetKey(p.name, selected = eq.preset == p.name, enabled = phone, onClick = { onPreset(p.name) })
            }
        }

        Text(
            if (phone) "Glisse les curseurs, ou touche deux fois un curseur pour le remettre à zéro."
            else "L’égaliseur agit sur le son du téléphone. En mode Fichiers, règle plutôt le grave et l’aigu de l’enceinte.",
            color = Hifi.engravingDim,
            fontSize = 12.sp,
        )
    }
}

@Composable
private fun EqCurve(eq: EqSettings, active: Boolean) {
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(72.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Hifi.vfdBack)
    ) {
        val pad = 10.dp.toPx()
        val w = size.width - pad * 2
        val h = size.height - pad * 2
        val color = if (active) Hifi.green else Hifi.engravingDim
        for (db in listOf(-6f, 0f, 6f)) {
            val y = pad + h * (EQ_MAX_DB - db) / (2 * EQ_MAX_DB)
            drawLine(color.copy(alpha = if (db == 0f) 0.3f else 0.12f), Offset(pad, y), Offset(pad + w, y), strokeWidth = 1f)
        }
        val last = (eq.gains.size - 1).coerceAtLeast(1)
        val pts = eq.gains.mapIndexed { i, g ->
            Offset(pad + w * i / last, pad + h * (EQ_MAX_DB - g) / (2 * EQ_MAX_DB))
        }
        val path = Path().apply {
            moveTo(pts[0].x, pts[0].y)
            for (i in 1 until pts.size) {
                val p0 = pts[i - 1]
                val p1 = pts[i]
                val mx = (p0.x + p1.x) / 2
                cubicTo(mx, p0.y, mx, p1.y, p1.x, p1.y)
            }
        }
        drawPath(path, color.copy(alpha = 0.35f), style = Stroke(6.dp.toPx(), cap = StrokeCap.Round))
        drawPath(path, color, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
        for (p in pts) drawCircle(color, radius = 2.5.dp.toPx(), center = p)
        drawRect(
            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.07f), Color.Transparent), endY = size.height * 0.5f)
        )
    }
}

@Composable
private fun EqFader(
    label: String,
    value: Float,
    enabled: Boolean,
    lit: Boolean,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val current by rememberUpdatedState(value)
    var dragValue by remember { mutableFloatStateOf(0f) }
    val haptic = LocalHapticFeedback.current

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .pointerInput(enabled) {
                    if (!enabled) return@pointerInput
                    detectVerticalDragGestures(onDragStart = { dragValue = current }) { change, dy ->
                        change.consume()
                        val travel = (size.height - 12.dp.toPx()).coerceAtLeast(1f)
                        dragValue = (dragValue - dy / travel * 2 * EQ_MAX_DB).coerceIn(-EQ_MAX_DB, EQ_MAX_DB)
                        val snapped = (dragValue * 2).roundToInt() / 2f
                        if (snapped != current) {
                            if (snapped == 0f) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onChange(snapped)
                        }
                    }
                }
                .pointerInput(enabled) {
                    if (!enabled) return@pointerInput
                    detectTapGestures(onDoubleTap = { onChange(0f) })
                }
        ) {
            val capH = 12.dp.toPx()
            val top = capH / 2
            val bottom = size.height - capH / 2
            fun yFor(db: Float) = top + (EQ_MAX_DB - db) / (2 * EQ_MAX_DB) * (bottom - top)
            val cx = size.width / 2

            for (db in listOf(-12f, -6f, 0f, 6f, 12f)) {
                val y = yFor(db)
                val len = if (db == 0f) 5.dp.toPx() else 3.dp.toPx()
                drawLine(Hifi.engravingDim, Offset(cx - 4.dp.toPx() - len, y), Offset(cx - 4.dp.toPx(), y), strokeWidth = 1f)
                drawLine(Hifi.engravingDim, Offset(cx + 4.dp.toPx(), y), Offset(cx + 4.dp.toPx() + len, y), strokeWidth = 1f)
            }
            drawRoundRect(
                Hifi.well,
                topLeft = Offset(cx - 2.dp.toPx(), top),
                size = Size(4.dp.toPx(), bottom - top),
                cornerRadius = CornerRadius(2.dp.toPx()),
            )
            val yv = yFor(value)
            if (lit && value != 0f) {
                drawLine(Hifi.green, Offset(cx, yFor(0f)), Offset(cx, yv), strokeWidth = 2.dp.toPx())
            }
            val capW = minOf(size.width - 2.dp.toPx(), 24.dp.toPx())
            drawRoundRect(
                Color.Black.copy(alpha = 0.5f),
                topLeft = Offset(cx - capW / 2 + 1f, yv - capH / 2 + 2.dp.toPx()),
                size = Size(capW, capH),
                cornerRadius = CornerRadius(2.dp.toPx()),
            )
            drawRoundRect(
                Brush.verticalGradient(
                    listOf(Hifi.keyTop, Hifi.keyBottom),
                    startY = yv - capH / 2,
                    endY = yv + capH / 2,
                ),
                topLeft = Offset(cx - capW / 2, yv - capH / 2),
                size = Size(capW, capH),
                cornerRadius = CornerRadius(2.dp.toPx()),
            )
            drawLine(
                if (lit) Hifi.green else Hifi.keyInk,
                Offset(cx - capW / 2 + 3.dp.toPx(), yv),
                Offset(cx + capW / 2 - 3.dp.toPx(), yv),
                strokeWidth = 1.5.dp.toPx(),
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Hifi.engravingDim, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun PresetKey(name: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(5.dp))
            .background(
                if (selected) Brush.verticalGradient(listOf(Color(0xFF5A5854), Color(0xFF2D2C29)))
                else SolidColor(Hifi.well)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Led(selected && enabled, color = Hifi.green, diameter = 6.dp)
        Spacer(Modifier.width(8.dp))
        Text(name, color = if (selected) Hifi.engraving else Hifi.engravingDim, fontSize = 13.sp)
    }
}

// ---------------------------------------------------------------- Tonalité de l'enceinte

@Composable
private fun TonePanel(
    state: HifiState,
    onBass: (Int) -> Unit,
    onTreble: (Int) -> Unit,
    onLoudness: () -> Unit,
) {
    val enabled = state.selected != null
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Engraved("Tonalité de l’enceinte")
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            MiniKnob("Grave", state.bass, enabled, onBass)
            MiniKnob("Aigu", state.treble, enabled, onTreble)
        }
        ToggleRow(on = state.loudness, label = "Loudness (plus de relief à bas volume)", onClick = onLoudness)
    }
}

@Composable
private fun MiniKnob(label: String, value: Int, enabled: Boolean, onChange: (Int) -> Unit) {
    val current by rememberUpdatedState(value)
    var accumulated by remember { mutableFloatStateOf(0f) }
    val haptic = LocalHapticFeedback.current

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier
                .size(116.dp)
                .pointerInput(enabled) {
                    if (!enabled) return@pointerInput
                    detectDragGestures(onDragStart = { accumulated = current.toFloat() }) { change, drag ->
                        change.consume()
                        accumulated = (accumulated + (drag.x - drag.y) / 14f).coerceIn(-10f, 10f)
                        val v = accumulated.roundToInt()
                        if (v != current) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onChange(v)
                        }
                    }
                }
                .pointerInput(enabled) {
                    if (!enabled) return@pointerInput
                    detectTapGestures(onDoubleTap = { onChange(0) })
                }
        ) {
            val c = center
            val r = size.minDimension / 2
            fun polar(deg: Float, radius: Float): Offset {
                val a = Math.toRadians((deg - 90f).toDouble())
                return Offset(c.x + radius * cos(a).toFloat(), c.y + radius * sin(a).toFloat())
            }
            // Graduation de -10 à +10, éclairée depuis le centre
            for (i in -10..10) {
                val deg = i * 13.5f
                val major = i % 5 == 0
                val litTick = enabled && ((value > 0 && i in 1..value) || (value < 0 && i in value..-1) || i == 0)
                drawLine(
                    if (litTick) Hifi.amber else Hifi.engravingDim.copy(alpha = 0.5f),
                    polar(deg, r * 0.82f),
                    polar(deg, if (major) r * 0.98f else r * 0.9f),
                    strokeWidth = if (major) 2.dp.toPx() else 1.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }
            val kr = r * 0.68f
            drawCircle(Color.Black.copy(alpha = 0.55f), radius = kr * 1.02f, center = c + Offset(0f, 4.dp.toPx()))
            drawCircle(
                Brush.verticalGradient(listOf(Color(0xFF5C5A56), Color(0xFF1B1A18)), startY = c.y - kr, endY = c.y + kr),
                radius = kr,
                center = c,
            )
            for (i in 0 until 60) {
                val deg = i * 6f
                drawLine(Color.Black.copy(alpha = 0.4f), polar(deg, kr * 0.86f), polar(deg, kr), strokeWidth = 1f)
            }
            val cr = kr * 0.8f
            drawCircle(
                Brush.sweepGradient(
                    listOf(
                        Color(0xFF8F8D88), Color(0xFFE2E0DB), Color(0xFF85837E), Color(0xFFD3D1CC),
                        Color(0xFF8A8883), Color(0xFFE4E2DD), Color(0xFF8F8D88),
                    ),
                    center = c,
                ),
                radius = cr,
                center = c,
            )
            drawCircle(Color.White.copy(alpha = 0.3f), radius = cr, center = c, style = Stroke(1.dp.toPx()))
            val deg = value * 13.5f
            val color = if (enabled) Hifi.amber else Hifi.engravingDim
            drawLine(color, polar(deg, cr * 0.45f), polar(deg, cr * 0.9f), strokeWidth = 2.5.dp.toPx(), cap = StrokeCap.Round)
        }
        Engraved(label)
        Spacer(Modifier.height(2.dp))
        VfdText(if (value > 0) "+$value" else value.toString(), 15.sp)
    }
}
