package com.example.sonoscast

import android.service.notification.NotificationListenerService

/**
 * Service vide : Android exige qu'il existe (et qu'il soit autorisé dans les réglages)
 * pour qu'une appli puisse piloter la lecture des autres applis.
 */
class MediaListenerService : NotificationListenerService()
