package com.example.sonoscast

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/** Fréquences centrales des 10 bandes (une par octave). */
val EQ_BANDS = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
val EQ_LABELS = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")
const val EQ_MAX_DB = 12f

data class EqSettings(
    val enabled: Boolean = true,
    val preamp: Float = 0f,
    val gains: List<Float> = List(EQ_BANDS.size) { 0f },
    val preset: String? = "Plat",
) {
    fun encode(): String =
        listOf(if (enabled) "1" else "0", preamp.toString(), gains.joinToString(","), preset ?: "").joinToString(";")

    companion object {
        fun decode(s: String?): EqSettings {
            if (s.isNullOrEmpty()) return EqSettings()
            return try {
                val parts = s.split(";")
                val gains = parts[2].split(",").map { it.toFloat().coerceIn(-EQ_MAX_DB, EQ_MAX_DB) }
                if (gains.size != EQ_BANDS.size) EqSettings()
                else EqSettings(
                    enabled = parts[0] == "1",
                    preamp = parts[1].toFloat().coerceIn(-EQ_MAX_DB, EQ_MAX_DB),
                    gains = gains,
                    preset = parts.getOrNull(3)?.ifEmpty { null },
                )
            } catch (e: Exception) {
                EqSettings()
            }
        }
    }
}

data class EqPreset(val name: String, val gains: List<Float>, val preamp: Float)

object EqPresets {
    val all: List<EqPreset> = listOf(
        preset("Plat", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
        preset("Rock", 5, 4, 3, 1, -1, -1, 1, 3, 4, 5),
        preset("Pop", -1, 1, 3, 4, 3, 0, -1, -1, 0, 1),
        preset("Jazz", 3, 2, 1, 2, -1, -1, 0, 1, 2, 3),
        preset("Classique", 2, 1, 0, 0, 0, 0, -2, -3, -3, -4),
        preset("Électro", 5, 4, 1, 0, -2, 1, 0, 1, 4, 5),
        preset("Basses+", 7, 6, 4, 2, 0, 0, 0, 0, 0, 0),
        preset("Voix", -3, -2, -1, 1, 3, 4, 4, 2, 0, -1),
        preset("Soirée", 6, 5, 2, 0, 0, 0, 2, 4, 5, 5),
    )

    fun find(name: String): EqPreset? = all.firstOrNull { it.name == name }

    private fun preset(name: String, vararg g: Int): EqPreset {
        val gains = g.map { it.toFloat() }
        val maxBoost = (gains.maxOrNull() ?: 0f).coerceAtLeast(0f)
        // On baisse le préampli de la moitié du plus fort boost pour éviter la saturation
        return EqPreset(name, gains, -(maxBoost / 2f))
    }
}

/** Réglages partagés entre l'interface et le service de capture. */
object EqStore {
    @Volatile
    var current: EqSettings = EqSettings()
}

/**
 * Égaliseur graphique : une cascade de filtres en cloche (biquads),
 * appliquée directement au son capté (PCM 16 bits entrelacé).
 */
class GraphicEq(private val sampleRate: Int, private val channels: Int) {

    private val bands = EQ_BANDS.size
    private val b0 = DoubleArray(bands)
    private val b1 = DoubleArray(bands)
    private val b2 = DoubleArray(bands)
    private val a1 = DoubleArray(bands)
    private val a2 = DoubleArray(bands)
    private val z1 = Array(channels) { DoubleArray(bands) }
    private val z2 = Array(channels) { DoubleArray(bands) }
    private val wasActive = BooleanArray(bands)
    private var active = IntArray(0)
    private var preGain = 1.0
    private var last: EqSettings? = null

    fun process(buffer: ByteArray, length: Int) {
        val settings = EqStore.current
        if (!settings.enabled) return
        if (settings !== last) rebuild(settings)
        if (active.isEmpty() && preGain == 1.0) return

        var i = 0
        var ch = 0
        while (i + 1 < length) {
            var x = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort().toDouble() * preGain
            val s1 = z1[ch]
            val s2 = z2[ch]
            for (k in active) {
                val y = b0[k] * x + s1[k]
                s1[k] = b1[k] * x - a1[k] * y + s2[k]
                s2[k] = b2[k] * x - a2[k] * y
                x = y
            }
            val out = x.roundToInt().coerceIn(-32768, 32767)
            buffer[i] = out.toByte()
            buffer[i + 1] = (out shr 8).toByte()
            i += 2
            ch = (ch + 1) % channels
        }
    }

    private fun rebuild(settings: EqSettings) {
        last = settings
        preGain = 10.0.pow(settings.preamp / 20.0)
        val list = ArrayList<Int>()
        for (k in 0 until bands) {
            val gain = settings.gains.getOrElse(k) { 0f }.toDouble()
            val on = gain != 0.0
            if (on) {
                if (!wasActive[k]) for (c in 0 until channels) { z1[c][k] = 0.0; z2[c][k] = 0.0 }
                list += k
                // Filtre en cloche (formules de R. Bristow-Johnson), une octave de large
                val a = 10.0.pow(gain / 40.0)
                val w0 = 2 * PI * EQ_BANDS[k] / sampleRate
                val alpha = sin(w0) / (2 * 1.41)
                val norm = 1 + alpha / a
                b0[k] = (1 + alpha * a) / norm
                b1[k] = (-2 * cos(w0)) / norm
                b2[k] = (1 - alpha * a) / norm
                a1[k] = (-2 * cos(w0)) / norm
                a2[k] = (1 - alpha / a) / norm
            }
            wasActive[k] = on
        }
        active = list.toIntArray()
    }
}
