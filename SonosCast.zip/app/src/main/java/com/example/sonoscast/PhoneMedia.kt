package com.example.sonoscast

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat

/** Pilote l'appli qui joue de la musique sur le téléphone (Spotify, YouTube, Deezer…). */
object PhoneMedia {

    data class NowPlaying(val title: String?, val artist: String?, val playing: Boolean)

    fun hasAccess(context: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    fun openAccessSettings(context: Context) {
        context.startActivity(
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun controller(context: Context): MediaController? {
        if (!hasAccess(context)) return null
        return try {
            val manager = context.getSystemService(MediaSessionManager::class.java) ?: return null
            val sessions = manager.getActiveSessions(ComponentName(context, MediaListenerService::class.java))
            sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: sessions.firstOrNull()
        } catch (e: Exception) {
            null
        }
    }

    fun nowPlaying(context: Context): NowPlaying? {
        val c = controller(context) ?: return null
        val metadata = c.metadata
        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
        return NowPlaying(title, artist, c.playbackState?.state == PlaybackState.STATE_PLAYING)
    }

    /** Exécute une commande sur l'appli en cours. Renvoie false s'il n'y en a pas. */
    fun command(context: Context, action: (MediaController) -> Unit): Boolean {
        val c = controller(context) ?: return false
        return try {
            action(c)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Avance ou recule de [deltaMs] millisecondes, si l'appli le permet. */
    fun seekBy(context: Context, deltaMs: Long): Boolean {
        val c = controller(context) ?: return false
        val state = c.playbackState ?: return false
        val forward = deltaMs > 0
        val fastAction = if (forward) PlaybackState.ACTION_FAST_FORWARD else PlaybackState.ACTION_REWIND
        return try {
            when {
                (state.actions and PlaybackState.ACTION_SEEK_TO) != 0L -> {
                    val elapsed = if (state.state == PlaybackState.STATE_PLAYING) {
                        ((SystemClock.elapsedRealtime() - state.lastPositionUpdateTime) * state.playbackSpeed).toLong()
                    } else 0L
                    c.transportControls.seekTo((state.position + elapsed + deltaMs).coerceAtLeast(0L))
                }
                (state.actions and fastAction) != 0L ->
                    if (forward) c.transportControls.fastForward() else c.transportControls.rewind()
                else -> return false
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
