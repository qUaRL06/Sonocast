package com.example.sonoscast

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

data class UiState(
    val groups: List<SonosGroup> = emptyList(),
    val selected: SonosGroup? = null,
    val searching: Boolean = false,
    val trackTitle: String? = null,
    val playing: Boolean = false,
    val volume: Int = 20,
    val message: String? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var track: AudioServer.Track? = null
    private var loadedOn: String? = null // "ip|token" déjà envoyé à l'enceinte

    init {
        discover()
    }

    fun discover() {
        viewModelScope.launch {
            _state.update { it.copy(searching = true, message = null) }
            val groups = runCatching { SonosDiscovery.discover(getApplication()) }
                .getOrDefault(emptyList())
            _state.update { s ->
                s.copy(
                    searching = false,
                    groups = groups,
                    selected = groups.firstOrNull { it.ip == s.selected?.ip } ?: groups.firstOrNull(),
                    message = if (groups.isEmpty())
                        "Aucune enceinte trouvée. Vérifie que le téléphone est sur le même Wi-Fi que la Sonos."
                    else null,
                )
            }
            refreshVolume()
        }
    }

    fun select(group: SonosGroup) {
        _state.update { it.copy(selected = group, playing = false) }
        refreshVolume()
    }

    fun onFilePicked(uri: Uri) {
        val resolver = getApplication<Application>().contentResolver
        runCatching { resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }

        var name = "Morceau"
        var size = -1L
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            ?.use { c ->
                if (c.moveToFirst()) {
                    c.getString(0)?.let { name = it }
                    if (!c.isNull(1)) size = c.getLong(1)
                }
            }
        val mime = resolver.getType(uri) ?: "audio/mpeg"
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
            ?: name.substringAfterLast('.', "mp3")
        val title = name.substringBeforeLast('.')

        track = AudioServer.Track(uri, mime, size, title, UUID.randomUUID().toString().take(8), ext)
        _state.update { it.copy(trackTitle = title, playing = false, message = null) }
    }

    fun togglePlay() = act {
        val group = state.value.selected ?: error("Choisis une enceinte.")
        val t = track ?: error("Choisis un fichier audio.")

        if (state.value.playing) {
            SonosController.pause(group.ip)
            _state.update { it.copy(playing = false) }
            return@act
        }

        val key = "${group.ip}|${t.token}"
        if (loadedOn == key) {
            SonosController.play(group.ip)
        } else {
            val app = getApplication<Application>()
            val phoneIp = localIpAddress() ?: error("Le téléphone n'est pas connecté au Wi-Fi.")
            withContext(Dispatchers.IO) { ServerHolder.ensureStarted(app).setTrack(t) }
            PlaybackService.start(app)
            val url = "http://$phoneIp:${AudioServer.PORT}/${t.token}.${t.ext}"
            SonosController.playUri(group.ip, url, t.title, t.mime)
            loadedOn = key
        }
        _state.update { it.copy(playing = true, message = null) }
    }

    fun stop() = act {
        val group = state.value.selected ?: return@act
        SonosController.stop(group.ip)
        loadedOn = null
        PlaybackService.stop(getApplication())
        _state.update { it.copy(playing = false) }
    }

    fun onVolumeChange(volume: Int) = _state.update { it.copy(volume = volume) }

    fun commitVolume() = act {
        val group = state.value.selected ?: return@act
        SonosController.setVolume(group.ip, state.value.volume)
    }

    private fun refreshVolume() = act {
        val group = state.value.selected ?: return@act
        val volume = SonosController.getVolume(group.ip)
        _state.update { it.copy(volume = volume) }
    }

    private fun act(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(message = e.message ?: "Erreur inattendue.") }
            }
        }
    }
}
