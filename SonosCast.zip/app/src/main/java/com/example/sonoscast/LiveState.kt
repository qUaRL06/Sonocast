package com.example.sonoscast

import kotlinx.coroutines.flow.MutableStateFlow

/** État partagé entre le service de capture et l'interface. */
object LiveState {
    /** true quand le son du téléphone est capté et servi sur le réseau. */
    val running = MutableStateFlow(false)

    /** Niveau sonore capté, de 0 (silence) à 1 (très fort), pour le vumètre. */
    val level = MutableStateFlow(0f)
}
