package com.example.sonoscast

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat

/**
 * Encode du son brut (PCM 16 bits) en AAC avec l'encodeur matériel du téléphone,
 * et emballe chaque trame avec un en-tête ADTS pour en faire un flux "radio".
 */
class AacEncoder(
    private val sampleRate: Int,
    private val channels: Int,
    bitrate: Int,
) {
    private val codec: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
    private val info = MediaCodec.BufferInfo()
    private var ptsUs = 0L
    private val freqIndex = intArrayOf(
        96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000
    ).indexOf(sampleRate).also { require(it >= 0) { "Fréquence non prise en charge" } }

    init {
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16 * 1024)
        }
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
    }

    fun encode(pcm: ByteArray, length: Int, onFrame: (ByteArray) -> Unit) {
        var offset = 0
        while (offset < length) {
            val inIndex = codec.dequeueInputBuffer(10_000)
            if (inIndex >= 0) {
                val input = codec.getInputBuffer(inIndex)!!
                input.clear()
                val n = minOf(input.remaining(), length - offset)
                input.put(pcm, offset, n)
                codec.queueInputBuffer(inIndex, 0, n, ptsUs, 0)
                ptsUs += n * 1_000_000L / (sampleRate * channels * 2)
                offset += n
            }
            drain(onFrame)
        }
    }

    private fun drain(onFrame: (ByteArray) -> Unit) {
        while (true) {
            val outIndex = codec.dequeueOutputBuffer(info, 0)
            if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) return
            if (outIndex < 0) continue // changement de format : on continue

            val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
            if (!isConfig && info.size > 0) {
                val out = codec.getOutputBuffer(outIndex)!!
                out.position(info.offset)
                out.limit(info.offset + info.size)
                val packet = ByteArray(info.size + 7)
                writeAdtsHeader(packet, packet.size)
                out.get(packet, 7, info.size)
                onFrame(packet)
            }
            codec.releaseOutputBuffer(outIndex, false)
        }
    }

    private fun writeAdtsHeader(packet: ByteArray, length: Int) {
        val profile = 2 // AAC LC
        packet[0] = 0xFF.toByte()
        packet[1] = 0xF1.toByte()
        packet[2] = (((profile - 1) shl 6) + (freqIndex shl 2) + (channels shr 2)).toByte()
        packet[3] = (((channels and 3) shl 6) + (length shr 11)).toByte()
        packet[4] = ((length and 0x7FF) shr 3).toByte()
        packet[5] = (((length and 7) shl 5) + 0x1F).toByte()
        packet[6] = 0xFC.toByte()
    }

    fun release() {
        runCatching { codec.stop() }
        runCatching { codec.release() }
    }
}
