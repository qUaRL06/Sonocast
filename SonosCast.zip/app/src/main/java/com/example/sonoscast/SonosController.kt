package com.example.sonoscast

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Pilote une Sonos via son API locale (SOAP sur le port 1400). */
object SonosController {

    private const val AVT = "urn:schemas-upnp-org:service:AVTransport:1"
    private const val GRC = "urn:schemas-upnp-org:service:GroupRenderingControl:1"
    private const val ZGT = "urn:schemas-upnp-org:service:ZoneGroupTopology:1"

    private const val AVT_PATH = "/MediaRenderer/AVTransport/Control"
    private const val GRC_PATH = "/MediaRenderer/GroupRenderingControl/Control"
    private const val ZGT_PATH = "/ZoneGroupTopology/Control"

    private const val INSTANCE = "<InstanceID>0</InstanceID>"

    suspend fun playUri(ip: String, url: String, title: String, mime: String) {
        val didl = "<DIDL-Lite xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
            "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\" " +
            "xmlns:r=\"urn:schemas-rinconnetworks-com:metadata-1-0/\" " +
            "xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\">" +
            "<item id=\"1\" parentID=\"0\" restricted=\"1\">" +
            "<dc:title>${esc(title)}</dc:title>" +
            "<upnp:class>object.item.audioItem.musicTrack</upnp:class>" +
            "<res protocolInfo=\"http-get:*:$mime:*\">${esc(url)}</res>" +
            "</item></DIDL-Lite>"

        soap(
            ip, AVT_PATH, AVT, "SetAVTransportURI",
            "$INSTANCE<CurrentURI>${esc(url)}</CurrentURI>" +
                "<CurrentURIMetaData>${esc(didl)}</CurrentURIMetaData>"
        )
        play(ip)
    }

    suspend fun play(ip: String) {
        soap(ip, AVT_PATH, AVT, "Play", "$INSTANCE<Speed>1</Speed>")
    }

    suspend fun pause(ip: String) {
        soap(ip, AVT_PATH, AVT, "Pause", INSTANCE)
    }

    suspend fun stop(ip: String) {
        soap(ip, AVT_PATH, AVT, "Stop", INSTANCE)
    }

    /** Volume du groupe entier (marche aussi pour une seule enceinte). */
    suspend fun setVolume(ip: String, volume: Int) {
        soap(
            ip, GRC_PATH, GRC, "SetGroupVolume",
            "$INSTANCE<DesiredVolume>${volume.coerceIn(0, 100)}</DesiredVolume>"
        )
    }

    suspend fun getVolume(ip: String): Int {
        val xml = soap(ip, GRC_PATH, GRC, "GetGroupVolume", INSTANCE)
        return Regex("<CurrentVolume>(\\d+)</CurrentVolume>").find(xml)
            ?.groupValues?.get(1)?.toInt() ?: 0
    }

    suspend fun zoneGroupState(ip: String): String =
        soap(ip, ZGT_PATH, ZGT, "GetZoneGroupState", "")

    private suspend fun soap(
        ip: String, path: String, service: String, action: String, args: String,
    ): String = withContext(Dispatchers.IO) {
        val body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
            "<s:Body><u:$action xmlns:u=\"$service\">$args</u:$action></s:Body></s:Envelope>"

        val conn = URL("http://$ip:1400$path").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 3000
            conn.readTimeout = 5000
            conn.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
            conn.setRequestProperty("SOAPACTION", "\"$service#$action\"")
            conn.outputStream.use { it.write(body.toByteArray()) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("La Sonos a refusé « $action » (code $code)")
            text
        } finally {
            conn.disconnect()
        }
    }

    private fun esc(s: String) = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
}
