package com.example.sonoscast

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Pilote une Sonos via son API locale (SOAP sur le port 1400). */
object SonosController {

    private const val AVT = "urn:schemas-upnp-org:service:AVTransport:1"
    private const val GRC = "urn:schemas-upnp-org:service:GroupRenderingControl:1"
    private const val ZGT = "urn:schemas-upnp-org:service:ZoneGroupTopology:1"

    private const val AVT_PATH = "/MediaRenderer/AVTransport/Control"
    private const val GRC_PATH = "/MediaRenderer/GroupRenderingControl/Control"
    private const val ZGT_PATH = "/ZoneGroupTopology/Control"

    private const val INSTANCE = "<InstanceID>0</InstanceID>"

    private const val DIDL_OPEN = "<DIDL-Lite xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
        "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\" " +
        "xmlns:r=\"urn:schemas-rinconnetworks-com:metadata-1-0/\" " +
        "xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\">"

    // ---------- Fichiers ----------

    suspend fun playUri(ip: String, url: String, title: String, mime: String) {
        val didl = DIDL_OPEN +
            "<item id=\"1\" parentID=\"0\" restricted=\"1\">" +
            "<dc:title>${esc(title)}</dc:title>" +
            "<upnp:class>object.item.audioItem.musicTrack</upnp:class>" +
            "<res protocolInfo=\"http-get:*:$mime:*\">${esc(url)}</res>" +
            "</item></DIDL-Lite>"
        setUri(ip, url, didl)
        play(ip)
    }

    // ---------- Flux en direct ----------

    /**
     * Lance le flux du téléphone comme une radio internet.
     * Plusieurs formes d'adresse existent selon les modèles : on les essaie une par une
     * jusqu'à ce que l'enceinte passe vraiment en lecture.
     */
    suspend fun playLiveStream(speakerIp: String, host: String, port: Int) {
        val path = "$host:$port/live.aac"
        val candidates = listOf(
            "x-rincon-mp3radio://$path",
            "aac://http://$path",
            "http://$path",
        )
        val didl = DIDL_OPEN +
            "<item id=\"R:0/0/0\" parentID=\"R:0/0\" restricted=\"true\">" +
            "<dc:title>Son du téléphone</dc:title>" +
            "<upnp:class>object.item.audioItem.audioBroadcast</upnp:class>" +
            "<desc id=\"cdudn\" nameSpace=\"urn:schemas-rinconnetworks-com:metadata-1-0/\">SA_RINCON65031_</desc>" +
            "</item></DIDL-Lite>"

        var lastError: Exception? = null
        for (uri in candidates) {
            try {
                setUri(speakerIp, uri, didl)
                play(speakerIp)
                if (waitForPlaying(speakerIp)) return
            } catch (e: IOException) {
                lastError = e
            }
        }
        throw IOException("La Sonos n’arrive pas à lire le son du téléphone", lastError)
    }

    private suspend fun waitForPlaying(ip: String): Boolean {
        repeat(30) { attempt ->
            delay(500)
            val st = runCatching { transportState(ip) }.getOrNull()
            if (st == "PLAYING") return true
            if (st == "STOPPED" && attempt >= 6) return false
        }
        return false
    }

    // ---------- Transport ----------

    suspend fun play(ip: String) {
        soap(ip, AVT_PATH, AVT, "Play", "$INSTANCE<Speed>1</Speed>")
    }

    suspend fun pause(ip: String) {
        soap(ip, AVT_PATH, AVT, "Pause", INSTANCE)
    }

    suspend fun stop(ip: String) {
        soap(ip, AVT_PATH, AVT, "Stop", INSTANCE)
    }

    suspend fun transportState(ip: String): String {
        val xml = soap(ip, AVT_PATH, AVT, "GetTransportInfo", INSTANCE)
        return tag(xml, "CurrentTransportState") ?: "UNKNOWN"
    }

    suspend fun seekTo(ip: String, seconds: Int) {
        val s = seconds.coerceAtLeast(0)
        val target = String.format(Locale.ROOT, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
        soap(ip, AVT_PATH, AVT, "Seek", "$INSTANCE<Unit>REL_TIME</Unit><Target>$target</Target>")
    }

    suspend fun seekBy(ip: String, deltaSeconds: Int) {
        val xml = soap(ip, AVT_PATH, AVT, "GetPositionInfo", INSTANCE)
        val position = parseTime(tag(xml, "RelTime"))
        val duration = parseTime(tag(xml, "TrackDuration"))
        var target = (position + deltaSeconds).coerceAtLeast(0)
        if (duration > 0) target = target.coerceAtMost(duration - 1)
        seekTo(ip, target)
    }

    // ---------- Volume ----------

    suspend fun setVolume(ip: String, volume: Int) {
        soap(
            ip, GRC_PATH, GRC, "SetGroupVolume",
            "$INSTANCE<DesiredVolume>${volume.coerceIn(0, 100)}</DesiredVolume>"
        )
    }

    suspend fun getVolume(ip: String): Int {
        val xml = soap(ip, GRC_PATH, GRC, "GetGroupVolume", INSTANCE)
        return tag(xml, "CurrentVolume")?.toIntOrNull() ?: 0
    }

    // ---------- Topologie ----------

    suspend fun zoneGroupState(ip: String): String =
        soap(ip, ZGT_PATH, ZGT, "GetZoneGroupState", "")

    // ---------- Outils ----------

    private suspend fun setUri(ip: String, uri: String, didl: String) {
        soap(
            ip, AVT_PATH, AVT, "SetAVTransportURI",
            "$INSTANCE<CurrentURI>${esc(uri)}</CurrentURI><CurrentURIMetaData>${esc(didl)}</CurrentURIMetaData>"
        )
    }

    private suspend fun soap(
        ip: String, path: String, service: String, action: String, args: String,
    ): String = withContext(Dispatchers.IO) {
        val body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
            "<s:Body><u:$action xmlns:u=\"$service\">$args</u:$action></s:Body></s:Envelope>"

        val conn = URL("http://$ip:1400$path").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 3000
            conn.readTimeout = 6000
            conn.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
            conn.setRequestProperty("SOAPACTION", "\"$service#$action\"")
            conn.outputStream.use { it.write(body.toByteArray()) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("La Sonos a refusé la commande « $action » (code $code)")
            text
        } finally {
            conn.disconnect()
        }
    }

    private fun tag(xml: String, name: String): String? =
        Regex("<$name>([^<]*)</$name>").find(xml)?.groupValues?.get(1)

    private fun parseTime(value: String?): Int {
        val parts = value?.split(":")?.mapNotNull { it.toIntOrNull() } ?: return 0
        if (parts.size != 3) return 0
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    }

    private fun esc(s: String) = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
}
