package com.example.sonoscast

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException

/** Une pièce ou un groupe de pièces. On envoie toujours les ordres au "coordinateur". */
data class SonosGroup(val name: String, val ip: String, val memberIps: List<String> = emptyList())

object SonosDiscovery {

    suspend fun discover(context: Context, timeoutMs: Long = 2500): List<SonosGroup> =
        withContext(Dispatchers.IO) {
            val ips = ssdpSearch(context, timeoutMs)
            // Une seule enceinte suffit pour connaître toute l'organisation des pièces
            for (ip in ips) {
                val groups = runCatching { groupsFrom(ip) }.getOrNull()
                if (!groups.isNullOrEmpty()) return@withContext groups
            }
            ips.map { SonosGroup(name = it, ip = it) }
        }

    /** Envoie un M-SEARCH SSDP en multicast et récupère les IP qui répondent. */
    private fun ssdpSearch(context: Context, timeoutMs: Long): Set<String> {
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wifi.createMulticastLock("sonoscast-discovery").apply {
            setReferenceCounted(false)
            acquire()
        }
        val found = mutableSetOf<String>()
        try {
            DatagramSocket().use { socket ->
                socket.soTimeout = 400
                val msg = ("M-SEARCH * HTTP/1.1\r\n" +
                    "HOST: 239.255.255.250:1900\r\n" +
                    "MAN: \"ssdp:discover\"\r\n" +
                    "MX: 1\r\n" +
                    "ST: urn:schemas-upnp-org:device:ZonePlayer:1\r\n\r\n").toByteArray()
                val group = InetAddress.getByName("239.255.255.250")
                repeat(3) { socket.send(DatagramPacket(msg, msg.size, group, 1900)) }

                val buf = ByteArray(2048)
                val end = System.currentTimeMillis() + timeoutMs
                while (System.currentTimeMillis() < end) {
                    try {
                        val packet = DatagramPacket(buf, buf.size)
                        socket.receive(packet)
                        val text = String(packet.data, 0, packet.length)
                        if (text.contains("Sonos", ignoreCase = true) || text.contains("ZonePlayer")) {
                            packet.address?.hostAddress?.let { found += it }
                        }
                    } catch (_: SocketTimeoutException) {
                        // on continue d'écouter jusqu'au délai
                    }
                }
            }
        } finally {
            lock.release()
        }
        return found
    }

    /** Lit la topologie (pièces, groupes, coordinateurs) depuis une enceinte. */
    private suspend fun groupsFrom(ip: String): List<SonosGroup> {
        val xml = unescape(SonosController.zoneGroupState(ip))
        val groupRe = Regex("<ZoneGroup\\s([^>]*)>(.*?)</ZoneGroup>", RegexOption.DOT_MATCHES_ALL)
        val memberRe = Regex("<ZoneGroupMember\\s([^>]*)>")

        return groupRe.findAll(xml).mapNotNull { g ->
            val coordinator = attrs(g.groupValues[1])["Coordinator"] ?: return@mapNotNull null
            val members = memberRe.findAll(g.groupValues[2]).map { attrs(it.groupValues[1]) }.toList()
            val coord = members.firstOrNull { it["UUID"] == coordinator } ?: return@mapNotNull null
            val coordIp = coord["Location"]
                ?.let { Regex("//([^:/]+)").find(it)?.groupValues?.get(1) }
                ?: return@mapNotNull null

            // On ignore les caissons, enceintes surround et Bridge/Boost
            val visible = members.filter { it["Invisible"] != "1" && it["IsZoneBridge"] != "1" }
            val name = visible
                .mapNotNull { it["ZoneName"]?.let { n -> unescape(n) } }
                .distinct()
                .joinToString(" + ")
            val ips = visible
                .mapNotNull { m -> m["Location"]?.let { Regex("//([^:/]+)").find(it)?.groupValues?.get(1) } }
                .distinct()
            if (name.isEmpty()) null else SonosGroup(name, coordIp, ips)
        }.sortedBy { it.name }.toList()
    }

    private fun attrs(s: String): Map<String, String> =
        Regex("(\\w+)=\"([^\"]*)\"").findAll(s)
            .associate { it.groupValues[1] to it.groupValues[2] }

    private fun unescape(s: String) = s
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'")
        .replace("&amp;", "&")
}
